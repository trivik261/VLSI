/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/sharan/Desktop/course/vlsi_lab/CED18I049_PROJECT/kogge/ppg.v";
static int ng1[] = {0, 0};
static int ng2[] = {16, 0};
static int ng3[] = {1, 0};



static void Always_28_0(char *t0)
{
    char t6[8];
    char t15[8];
    char t23[8];
    char t29[8];
    char t44[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    char *t43;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    unsigned int t52;
    int t53;
    unsigned int t54;
    unsigned int t55;
    int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    int t64;

LAB0:    t1 = (t0 + 3160U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(28, ng0);
    t2 = (t0 + 3976);
    *((int *)t2) = 1;
    t3 = (t0 + 3192);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(29, ng0);

LAB5:    xsi_set_current_line(30, ng0);
    xsi_set_current_line(30, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 2248);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB6:    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB7;

LAB8:    goto LAB2;

LAB7:    xsi_set_current_line(31, ng0);

LAB9:    xsi_set_current_line(32, ng0);
    t13 = (t0 + 1048U);
    t14 = *((char **)t13);
    t13 = (t0 + 1008U);
    t16 = (t13 + 72U);
    t17 = *((char **)t16);
    t18 = (t0 + 2248);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    xsi_vlog_generic_get_index_select_value(t15, 1, t14, t17, 2, t20, 32, 1);
    t21 = (t0 + 1208U);
    t22 = *((char **)t21);
    t21 = (t0 + 1168U);
    t24 = (t21 + 72U);
    t25 = *((char **)t24);
    t26 = (t0 + 2248);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    xsi_vlog_generic_get_index_select_value(t23, 1, t22, t25, 2, t28, 32, 1);
    t30 = *((unsigned int *)t15);
    t31 = *((unsigned int *)t23);
    t32 = (t30 ^ t31);
    *((unsigned int *)t29) = t32;
    t33 = (t15 + 4);
    t34 = (t23 + 4);
    t35 = (t29 + 4);
    t36 = *((unsigned int *)t33);
    t37 = *((unsigned int *)t34);
    t38 = (t36 | t37);
    *((unsigned int *)t35) = t38;
    t39 = *((unsigned int *)t35);
    t40 = (t39 != 0);
    if (t40 == 1)
        goto LAB10;

LAB11:
LAB12:    t43 = (t0 + 1928);
    t45 = (t0 + 1928);
    t46 = (t45 + 72U);
    t47 = *((char **)t46);
    t48 = (t0 + 2248);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    xsi_vlog_generic_convert_bit_index(t44, t47, 2, t50, 32, 1);
    t51 = (t44 + 4);
    t52 = *((unsigned int *)t51);
    t53 = (!(t52));
    if (t53 == 1)
        goto LAB13;

LAB14:    xsi_set_current_line(33, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t0 + 1008U);
    t4 = (t2 + 72U);
    t5 = *((char **)t4);
    t7 = (t0 + 2248);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    xsi_vlog_generic_get_index_select_value(t6, 1, t3, t5, 2, t14, 32, 1);
    t16 = (t0 + 1208U);
    t17 = *((char **)t16);
    t16 = (t0 + 1168U);
    t18 = (t16 + 72U);
    t19 = *((char **)t18);
    t20 = (t0 + 2248);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    xsi_vlog_generic_get_index_select_value(t15, 1, t17, t19, 2, t22, 32, 1);
    t8 = *((unsigned int *)t6);
    t9 = *((unsigned int *)t15);
    t10 = (t8 & t9);
    *((unsigned int *)t23) = t10;
    t24 = (t6 + 4);
    t25 = (t15 + 4);
    t26 = (t23 + 4);
    t11 = *((unsigned int *)t24);
    t12 = *((unsigned int *)t25);
    t30 = (t11 | t12);
    *((unsigned int *)t26) = t30;
    t31 = *((unsigned int *)t26);
    t32 = (t31 != 0);
    if (t32 == 1)
        goto LAB15;

LAB16:
LAB17:    t33 = (t0 + 2088);
    t34 = (t0 + 2088);
    t35 = (t34 + 72U);
    t43 = *((char **)t35);
    t45 = (t0 + 2248);
    t46 = (t45 + 56U);
    t47 = *((char **)t46);
    xsi_vlog_generic_convert_bit_index(t29, t43, 2, t47, 32, 1);
    t48 = (t29 + 4);
    t63 = *((unsigned int *)t48);
    t64 = (!(t63));
    if (t64 == 1)
        goto LAB18;

LAB19:    xsi_set_current_line(30, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 2248);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB6;

LAB10:    t41 = *((unsigned int *)t29);
    t42 = *((unsigned int *)t35);
    *((unsigned int *)t29) = (t41 | t42);
    goto LAB12;

LAB13:    xsi_vlogvar_assign_value(t43, t29, 0, *((unsigned int *)t44), 1);
    goto LAB14;

LAB15:    t36 = *((unsigned int *)t23);
    t37 = *((unsigned int *)t26);
    *((unsigned int *)t23) = (t36 | t37);
    t27 = (t6 + 4);
    t28 = (t15 + 4);
    t38 = *((unsigned int *)t6);
    t39 = (~(t38));
    t40 = *((unsigned int *)t27);
    t41 = (~(t40));
    t42 = *((unsigned int *)t15);
    t52 = (~(t42));
    t54 = *((unsigned int *)t28);
    t55 = (~(t54));
    t53 = (t39 & t41);
    t56 = (t52 & t55);
    t57 = (~(t53));
    t58 = (~(t56));
    t59 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t59 & t57);
    t60 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t60 & t58);
    t61 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t61 & t57);
    t62 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t62 & t58);
    goto LAB17;

LAB18:    xsi_vlogvar_assign_value(t33, t23, 0, *((unsigned int *)t29), 1);
    goto LAB19;

}

static void Cont_37_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 3408U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(37, ng0);
    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4088);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 65535U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 15);
    t18 = (t0 + 3992);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_38_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 3656U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4152);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 65535U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 15);
    t18 = (t0 + 4008);
    *((int *)t18) = 1;

LAB1:    return;
}


extern void work_m_13057614084777896252_2858310404_init()
{
	static char *pe[] = {(void *)Always_28_0,(void *)Cont_37_1,(void *)Cont_38_2};
	xsi_register_didat("work_m_13057614084777896252_2858310404", "isim/adder_isim_beh.exe.sim/work/m_13057614084777896252_2858310404.didat");
	xsi_register_executes(pe);
}
