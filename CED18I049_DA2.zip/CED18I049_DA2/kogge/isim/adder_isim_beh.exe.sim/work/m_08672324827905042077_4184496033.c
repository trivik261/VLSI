/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/sharan/Desktop/course/vlsi_lab/CED18I049_PROJECT/kogge/level2.v";
static int ng1[] = {0, 0};
static int ng2[] = {16, 0};
static int ng3[] = {1, 0};
static int ng4[] = {4, 0};
static int ng5[] = {15, 0};
static int ng6[] = {2, 0};



static void Always_29_0(char *t0)
{
    char t6[8];
    char t15[8];
    char t22[8];
    char t32[8];
    char t34[8];
    char t45[8];
    char t46[8];
    char t47[8];
    char t80[8];
    char t87[8];
    char t116[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    unsigned int t30;
    int t31;
    char *t33;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    unsigned int t48;
    unsigned int t49;
    char *t50;
    char *t51;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    char *t60;
    char *t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    char *t77;
    char *t78;
    char *t79;
    char *t81;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    char *t86;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t91;
    char *t92;
    char *t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    char *t101;
    char *t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    int t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    int t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    char *t115;
    char *t117;
    char *t118;
    char *t119;
    char *t120;
    char *t121;
    char *t122;
    char *t123;
    unsigned int t124;
    int t125;

LAB0:    t1 = (t0 + 3480U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(29, ng0);
    t2 = (t0 + 4296);
    *((int *)t2) = 1;
    t3 = (t0 + 3512);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(30, ng0);

LAB5:    xsi_set_current_line(31, ng0);
    xsi_set_current_line(31, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 2568);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB6:    t2 = (t0 + 2568);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB7;

LAB8:    xsi_set_current_line(37, ng0);
    xsi_set_current_line(37, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2408);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB14:    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB15;

LAB16:    goto LAB2;

LAB7:    xsi_set_current_line(32, ng0);

LAB9:    xsi_set_current_line(33, ng0);
    t13 = (t0 + 1048U);
    t14 = *((char **)t13);
    t13 = (t0 + 1008U);
    t16 = (t13 + 72U);
    t17 = *((char **)t16);
    t18 = (t0 + 2568);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    xsi_vlog_generic_get_index_select_value(t15, 1, t14, t17, 2, t20, 32, 1);
    t21 = (t0 + 1928);
    t23 = (t0 + 1928);
    t24 = (t23 + 72U);
    t25 = *((char **)t24);
    t26 = (t0 + 2568);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    xsi_vlog_generic_convert_bit_index(t22, t25, 2, t28, 32, 1);
    t29 = (t22 + 4);
    t30 = *((unsigned int *)t29);
    t31 = (!(t30));
    if (t31 == 1)
        goto LAB10;

LAB11:    xsi_set_current_line(34, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 1168U);
    t4 = (t2 + 72U);
    t5 = *((char **)t4);
    t7 = (t0 + 2568);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    xsi_vlog_generic_get_index_select_value(t6, 1, t3, t5, 2, t14, 32, 1);
    t16 = (t0 + 2088);
    t17 = (t0 + 2088);
    t18 = (t17 + 72U);
    t19 = *((char **)t18);
    t20 = (t0 + 2568);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    xsi_vlog_generic_convert_bit_index(t15, t19, 2, t23, 32, 1);
    t24 = (t15 + 4);
    t8 = *((unsigned int *)t24);
    t31 = (!(t8));
    if (t31 == 1)
        goto LAB12;

LAB13:    xsi_set_current_line(31, ng0);
    t2 = (t0 + 2568);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 2568);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB6;

LAB10:    xsi_vlogvar_assign_value(t21, t15, 0, *((unsigned int *)t22), 1);
    goto LAB11;

LAB12:    xsi_vlogvar_assign_value(t16, t6, 0, *((unsigned int *)t15), 1);
    goto LAB13;

LAB15:    xsi_set_current_line(38, ng0);

LAB17:    xsi_set_current_line(39, ng0);
    xsi_set_current_line(39, ng0);
    t13 = ((char*)((ng5)));
    t14 = (t0 + 2248);
    xsi_vlogvar_assign_value(t14, t13, 0, 0, 32);

LAB18:    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng6)));
    t7 = (t0 + 2408);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    memset(t6, 0, 8);
    xsi_vlog_signed_power(t6, 32, t5, 32, t14, 32, 1);
    memset(t15, 0, 8);
    xsi_vlog_signed_minus(t15, 32, t4, 32, t6, 32);
    t16 = ((char*)((ng1)));
    memset(t22, 0, 8);
    xsi_vlog_signed_greatereq(t22, 32, t15, 32, t16, 32);
    t17 = (t22 + 4);
    t8 = *((unsigned int *)t17);
    t9 = (~(t8));
    t10 = *((unsigned int *)t22);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB19;

LAB20:    xsi_set_current_line(37, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 2408);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB14;

LAB19:    xsi_set_current_line(40, ng0);

LAB21:    xsi_set_current_line(41, ng0);
    t18 = (t0 + 1928);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t0 + 1928);
    t23 = (t21 + 72U);
    t24 = *((char **)t23);
    t25 = (t0 + 2248);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    xsi_vlog_generic_get_index_select_value(t32, 1, t20, t24, 2, t27, 32, 1);
    t28 = (t0 + 2088);
    t29 = (t28 + 56U);
    t33 = *((char **)t29);
    t35 = (t0 + 2088);
    t36 = (t35 + 72U);
    t37 = *((char **)t36);
    t38 = (t0 + 2248);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    t41 = ((char*)((ng6)));
    t42 = (t0 + 2408);
    t43 = (t42 + 56U);
    t44 = *((char **)t43);
    memset(t45, 0, 8);
    xsi_vlog_signed_power(t45, 32, t41, 32, t44, 32, 1);
    memset(t46, 0, 8);
    xsi_vlog_signed_minus(t46, 32, t40, 32, t45, 32);
    xsi_vlog_generic_get_index_select_value(t34, 1, t33, t37, 2, t46, 32, 1);
    t30 = *((unsigned int *)t32);
    t48 = *((unsigned int *)t34);
    t49 = (t30 & t48);
    *((unsigned int *)t47) = t49;
    t50 = (t32 + 4);
    t51 = (t34 + 4);
    t52 = (t47 + 4);
    t53 = *((unsigned int *)t50);
    t54 = *((unsigned int *)t51);
    t55 = (t53 | t54);
    *((unsigned int *)t52) = t55;
    t56 = *((unsigned int *)t52);
    t57 = (t56 != 0);
    if (t57 == 1)
        goto LAB22;

LAB23:
LAB24:    t77 = (t0 + 2088);
    t78 = (t77 + 56U);
    t79 = *((char **)t78);
    t81 = (t0 + 2088);
    t82 = (t81 + 72U);
    t83 = *((char **)t82);
    t84 = (t0 + 2248);
    t85 = (t84 + 56U);
    t86 = *((char **)t85);
    xsi_vlog_generic_get_index_select_value(t80, 1, t79, t83, 2, t86, 32, 1);
    t88 = *((unsigned int *)t47);
    t89 = *((unsigned int *)t80);
    t90 = (t88 | t89);
    *((unsigned int *)t87) = t90;
    t91 = (t47 + 4);
    t92 = (t80 + 4);
    t93 = (t87 + 4);
    t94 = *((unsigned int *)t91);
    t95 = *((unsigned int *)t92);
    t96 = (t94 | t95);
    *((unsigned int *)t93) = t96;
    t97 = *((unsigned int *)t93);
    t98 = (t97 != 0);
    if (t98 == 1)
        goto LAB25;

LAB26:
LAB27:    t115 = (t0 + 2088);
    t117 = (t0 + 2088);
    t118 = (t117 + 72U);
    t119 = *((char **)t118);
    t120 = (t0 + 2248);
    t121 = (t120 + 56U);
    t122 = *((char **)t121);
    xsi_vlog_generic_convert_bit_index(t116, t119, 2, t122, 32, 1);
    t123 = (t116 + 4);
    t124 = *((unsigned int *)t123);
    t125 = (!(t124));
    if (t125 == 1)
        goto LAB28;

LAB29:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 1928);
    t7 = (t5 + 72U);
    t13 = *((char **)t7);
    t14 = (t0 + 2248);
    t16 = (t14 + 56U);
    t17 = *((char **)t16);
    xsi_vlog_generic_get_index_select_value(t6, 1, t4, t13, 2, t17, 32, 1);
    t18 = (t0 + 1928);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t0 + 1928);
    t23 = (t21 + 72U);
    t24 = *((char **)t23);
    t25 = (t0 + 2248);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    t28 = ((char*)((ng6)));
    t29 = (t0 + 2408);
    t33 = (t29 + 56U);
    t35 = *((char **)t33);
    memset(t22, 0, 8);
    xsi_vlog_signed_power(t22, 32, t28, 32, t35, 32, 1);
    memset(t32, 0, 8);
    xsi_vlog_signed_minus(t32, 32, t27, 32, t22, 32);
    xsi_vlog_generic_get_index_select_value(t15, 1, t20, t24, 2, t32, 32, 1);
    t8 = *((unsigned int *)t6);
    t9 = *((unsigned int *)t15);
    t10 = (t8 & t9);
    *((unsigned int *)t34) = t10;
    t36 = (t6 + 4);
    t37 = (t15 + 4);
    t38 = (t34 + 4);
    t11 = *((unsigned int *)t36);
    t12 = *((unsigned int *)t37);
    t30 = (t11 | t12);
    *((unsigned int *)t38) = t30;
    t48 = *((unsigned int *)t38);
    t49 = (t48 != 0);
    if (t49 == 1)
        goto LAB30;

LAB31:
LAB32:    t41 = (t0 + 1928);
    t42 = (t0 + 1928);
    t43 = (t42 + 72U);
    t44 = *((char **)t43);
    t50 = (t0 + 2248);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    xsi_vlog_generic_convert_bit_index(t45, t44, 2, t52, 32, 1);
    t60 = (t45 + 4);
    t72 = *((unsigned int *)t60);
    t106 = (!(t72));
    if (t106 == 1)
        goto LAB33;

LAB34:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_signed_minus(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 2248);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB18;

LAB22:    t58 = *((unsigned int *)t47);
    t59 = *((unsigned int *)t52);
    *((unsigned int *)t47) = (t58 | t59);
    t60 = (t32 + 4);
    t61 = (t34 + 4);
    t62 = *((unsigned int *)t32);
    t63 = (~(t62));
    t64 = *((unsigned int *)t60);
    t65 = (~(t64));
    t66 = *((unsigned int *)t34);
    t67 = (~(t66));
    t68 = *((unsigned int *)t61);
    t69 = (~(t68));
    t31 = (t63 & t65);
    t70 = (t67 & t69);
    t71 = (~(t31));
    t72 = (~(t70));
    t73 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t73 & t71);
    t74 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t74 & t72);
    t75 = *((unsigned int *)t47);
    *((unsigned int *)t47) = (t75 & t71);
    t76 = *((unsigned int *)t47);
    *((unsigned int *)t47) = (t76 & t72);
    goto LAB24;

LAB25:    t99 = *((unsigned int *)t87);
    t100 = *((unsigned int *)t93);
    *((unsigned int *)t87) = (t99 | t100);
    t101 = (t47 + 4);
    t102 = (t80 + 4);
    t103 = *((unsigned int *)t101);
    t104 = (~(t103));
    t105 = *((unsigned int *)t47);
    t106 = (t105 & t104);
    t107 = *((unsigned int *)t102);
    t108 = (~(t107));
    t109 = *((unsigned int *)t80);
    t110 = (t109 & t108);
    t111 = (~(t106));
    t112 = (~(t110));
    t113 = *((unsigned int *)t93);
    *((unsigned int *)t93) = (t113 & t111);
    t114 = *((unsigned int *)t93);
    *((unsigned int *)t93) = (t114 & t112);
    goto LAB27;

LAB28:    xsi_vlogvar_assign_value(t115, t87, 0, *((unsigned int *)t116), 1);
    goto LAB29;

LAB30:    t53 = *((unsigned int *)t34);
    t54 = *((unsigned int *)t38);
    *((unsigned int *)t34) = (t53 | t54);
    t39 = (t6 + 4);
    t40 = (t15 + 4);
    t55 = *((unsigned int *)t6);
    t56 = (~(t55));
    t57 = *((unsigned int *)t39);
    t58 = (~(t57));
    t59 = *((unsigned int *)t15);
    t62 = (~(t59));
    t63 = *((unsigned int *)t40);
    t64 = (~(t63));
    t31 = (t56 & t58);
    t70 = (t62 & t64);
    t65 = (~(t31));
    t66 = (~(t70));
    t67 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t67 & t65);
    t68 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t68 & t66);
    t69 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t69 & t65);
    t71 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t71 & t66);
    goto LAB32;

LAB33:    xsi_vlogvar_assign_value(t41, t34, 0, *((unsigned int *)t45), 1);
    goto LAB34;

}

static void Cont_48_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 3728U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4408);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 65535U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 15);
    t18 = (t0 + 4312);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_49_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 3976U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4472);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 65535U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 15);
    t18 = (t0 + 4328);
    *((int *)t18) = 1;

LAB1:    return;
}


extern void work_m_08672324827905042077_4184496033_init()
{
	static char *pe[] = {(void *)Always_29_0,(void *)Cont_48_1,(void *)Cont_49_2};
	xsi_register_didat("work_m_08672324827905042077_4184496033", "isim/adder_isim_beh.exe.sim/work/m_08672324827905042077_4184496033.didat");
	xsi_register_executes(pe);
}
